import React from 'react'
import { HomePage } from './ram/';

export const AppRAM = () => {
  return (
    <div>
      <HomePage />
    </div>
  )
}
