

export const FooterComponent = () => {
  return (
    <div>FooterComponent</div>
  )
}
