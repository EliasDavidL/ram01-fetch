<p align='left'>
  <img src="https://www.frba.utn.edu.ar/wp-content/uploads/2019/10/logo-UTNBA-PNC-2016-2019-e1570223041254.png" />
</P>

---

# `Pasos a seguir`

Descargar este repositorio `Download ZIP` o bien clonar el mismo.

![Context](./src/assets/readme-1.png)

En el caso de haber descargado el repositorio deben descomprimir el archivo y lo abren en su editor de texto preferido.

Para hacer la instalación de dependencias se deberán posicionar en la terminal en el directorio raíz del proyecto (donde se encuentra el package.json) y ejecutar el siguiente comando:

```
npm install
```

Una vez realizada la instalación de dependencias ya pueden trabajar con este repositorio.

Abrir el archivo `TUTORIAL.md` con vista previa. Para ello hacer "Clic" secundario sobre el archivo y seleccionar "Abrir con vista previa" u "open preview" y seguir el tutorial.

Si se sienten más cómodos también pueden abrirlo en este mismo repositorio en GitHub con un simple clic en el archivo.

![Context](./src/assets/readme-2.png)
